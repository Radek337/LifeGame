import { useState } from 'react'
import Block from './block'


function LifeContainerFill(){
    let blocks = [];
    for(let columns=1; columns<=10; columns++){
        for(let rows=1; rows<=10; rows++){
            blocks.push(<Block xCoordinate={rows} yCoordinate={columns}></Block>)
        }
    }

return (
    <div className="lifeContainer">
          {blocks}
    </div>
)
}
export default LifeContainerFill