import { useState } from 'react'
import './App.css'
import LifeContainerFill from './LifeContainerFill'
import play from './functions'
import {ColorPalet, changeColor} from './ColorPalet'

function App() {
  return (
    <div className="App">
      <button onClick={play}>Play</button>
      <LifeContainerFill></LifeContainerFill>
      <ColorPalet></ColorPalet>
    </div>

  )
}

export default App
