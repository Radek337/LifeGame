import { useState } from 'react'

export function ColorPalet(){
    return(
        <div className="colorPalet"><input type="color" name="" id="colorPalet" /><button onClick={changeColor}>Nie klikaj mie!!!!!!</button></div>   
    )
}

export function changeColor(){
   let lifeItems: any = document.querySelectorAll('.lifeItem')
   let colorPicker: any = document.getElementById('colorPalet')
   lifeItems.forEach( (element: any) => {
       element.style.backgroundColor = colorPicker.value
   });
}