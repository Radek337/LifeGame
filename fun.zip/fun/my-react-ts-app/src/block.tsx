import { useState } from 'react'

type Block = {
    xCoordinate: number,
    yCoordinate: number
}


function Block({xCoordinate, yCoordinate}:Block){
    const [state, setNstate] = useState(false)
    return (
        <div onClick={()=>{
            setNstate(()=> !state)
        }} data-x={xCoordinate} data-y={yCoordinate} data-state={state} className="lifeItem"></div>
    )
}

export default Block