import './App.css'
import Block from './block'

function play(){
    let items = document.querySelectorAll('.lifeItem')
    let trueItems: any[] = []
    let newTrueItems: any[] = []
    items.forEach((lifeItem)=>{
        if(lifeItem.getAttribute('data-state') === 'true'){
            trueItems.push(lifeItem)
        }
    })
    console.log(trueItems)
    trueItems.forEach((lifeItem)=>{
        let x = parseInt(lifeItem.getAttribute('data-x'));
        let y = parseInt(lifeItem.getAttribute('data-y'));
        newTrueItems.push(document.querySelector(`.lifeItem[data-x="${x-1}"].lifeItem[data-y="${y}"]`))
        newTrueItems.push(document.querySelector(`.lifeItem[data-x="${x+1}"].lifeItem[data-y="${y}"]`))
        newTrueItems.push(document.querySelector(`.lifeItem[data-y="${y-1}"].lifeItem[data-x="${x}"]`))
        newTrueItems.push(document.querySelector(`.lifeItem[data-y="${y+1}"].lifeItem[data-x="${x}"]`))
    })
    console.log(newTrueItems)
    newTrueItems = newTrueItems.filter( (item)=>{
        return item !== null
    })
    console.log(newTrueItems)

    newTrueItems.forEach((item)=>{
        item.setAttribute('data-state',true)
    })
    trueItems.forEach((item)=>{
        item.setAttribute('data-state',false)
    })
}


export default play